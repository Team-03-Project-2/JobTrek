const roles = {
  Administrator: "Administrator",
  JobSeeker: "Job Seeker"
}

module.exports = roles;